<?php 
	include  'koneksi.php';


	session_start();
	$nama = $_GET['nama'];
	$hari = $_GET['hari'];
	$film = $_GET['film'];
	$jam = $_GET['jam'];
	$tiket = $_GET['tiket'];
	$kursi = $_GET['kursi'];
	$nomor = $_GET['nomor'];
	//$waktu = $_POST['waktu'];
	
	

	$tambah = mysqli_query($conn,"INSERT INTO pesanan VALUES(null,'$nama','$hari','$film','$jam','$tiket','$kursi','$nomor',null)");

		if ($tambah>0) {
			echo "Data anda berhasil ditambahkan";
			echo "<br>";
			echo "klik ";
			echo "<a href='order.php'>disini</a>";
			echo " Untuk melihat hasil";
		}
		else {
			echo "Data anda gagal ditambahkan";
			echo "<br>";
			echo "klik ";
			echo "<a href='creat.php'>disini</a>";
		echo " Gan";

		}
	

 ?>