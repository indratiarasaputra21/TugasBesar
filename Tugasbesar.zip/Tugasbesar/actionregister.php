<?php 
	include 'koneksi.php';
	session_start();
	
	$username = $_POST['username'];
	$password = $_POST['password'];

	$result = mysqli_query($conn,"INSERT INTO user VALUES(null,'$username','$password')");

	if ($result) {
		echo "Sudah Bisa Masuk Gan";
		echo("<br>");
		echo "login ";
		echo "<a href='register.php'>disini</a>";
		echo " Gan";
	}
	else {
		echo "Gagal Login Gan ";
		echo "<a href='formregister.php'> Try Agaian Gan</a>";
	}


?>