<?php 	
	$conn = mysqli_connect("localhost","root","","bioskop");

	function query ($query){
		global $conn;
		$result = mysqli_query ($conn,$query);
		$rows = [];

		while ($bioskop = mysqli_fetch_assoc($result)) {
			$rows[]=$bioskop;
		}
		return $rows;
	}

	function hapus ($id){
		global $conn;
		mysqli_query($conn, "DELETE FROM blog WHERE id = $id");
		return mysqli_affected_rows($conn); 
	}


	function ubah($data)
	{
		global $conn;

		$id = $data["id"];
		$hari = htmlspecialchars($data["hari"]);
		$film = htmlspecialchars($data["film"]);
		$tayang = htmlspecialchars($data["tayang"]);

		$query = "UPDATE blog SET hari = '$hari', film = '$film',tayang = '$tayang' WHERE id = $id";

		mysqli_query ($conn, $query);
		return mysqli_affected_rows ($conn);
	}

	 function creat ($data)
	 {
	 	global $conn;

    	$hari = $data["hari"];
	 	$film = $data["film"];
		$tayang = $data["tayang"];
		

	 	$query = "INSERT INTO blog VALUES ('','$hari', '$film', '$tayang')";

	 	mysql_query($conn, $query);

	 	return mysqli_affected_rows($conn);
	 }
	 
	 
 ?>